VINAY YADAV — PERSONAL PORTFOLIO

Files:
- index.html: your responsive one-page portfolio website.

Before publishing:
1. Open index.html in a browser and review every section.
2. Your contact email is set to vinayyadavbathni@gmail.com.
3. Add your LinkedIn and GitHub links if you want them shown.
4. Add genuine screenshots/images of your Photoshop work and project work.
5. Check all education details and project descriptions against your certificates/resume.

To get a public website link:
- Upload this folder to GitHub and enable GitHub Pages, or
- Drag the folder into Netlify Drop (https://app.netlify.com/drop).
The hosting service will provide a public HTTPS URL. Use that URL in the job application Website field.
